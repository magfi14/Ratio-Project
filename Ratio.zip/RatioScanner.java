import java.util.Scanner;

public class RatioScanner {

	private Scanner scanner;
	private Ratio ratio;

	public RatioScanner() {

		this.scanner = new Scanner(System.in);
		this.ratio = new Ratio();

	}

	public RatioScanner(Scanner scanner, Ratio ratio) {

		this.scanner = scanner;
		this.ratio = ratio;

	}

	private void feedbackLoop(String message) {
		System.out.println(message);
		boolean isNextBool = this.scanner.hasNextBoolean(), hasNextOperand = false;
		do {
			if (isNextBool) {
				hasNextOperand = scanner.nextBoolean();
				break;
			}
		} while (!(isNextBool));
	}

	private void addOperand() {

		this.feedbackLoop("Add an operand? (Type 'true' for true, 'false' for false)");
		System.out.println("Enter an integer.");
		int nextOperand = 1;
		boolean nextOperandBool = this.scanner.hasNextInt();
		if (nextOperandBool)
			nextOperand = this.scanner.nextInt();
		this.ratio.addPart(nextOperand);

	}

	private void remOperand() {

		this.feedbackLoop("Remove an operand? (Type 'true' for true, 'false' for false)");
		System.out.println("Enter an index.");
		int nextIndex = 0;
		boolean nextIndexBool = this.scanner.hasNextInt();
		if (nextIndexBool)
			nextIndex = this.scanner.nextInt();
		this.ratio.deletePart(nextIndex);

	}

	private void computeRatio() {

		this.feedbackLoop("Compute Ratio? (Type 'true' for true, 'false' for false)");
		boolean canComputeRatio = this.scanner.nextBoolean();
		if (canComputeRatio)
			System.out.println(this.ratio);

	}

	public void buildRatio() {

		String prompt = "", realPrompt = "";
		System.out.println("Building ratio");
		do {
			System.out.println(
					"Type 'compute' to compute the ratio. Type 'add' to add a part to the ratio. Type 'delete' to remove an index from the ratio.");
			prompt = this.scanner.next();
			realPrompt = prompt.toLowerCase();
			switch (realPrompt) {
				case "compute":
					this.computeRatio();
					break;
				case "add":
					this.addOperand();
					break;
				case "delete":
					this.remOperand();
					break;
				default:
					break;
			}
		} while (!(prompt.equals("compute")));

	}

}