import java.util.Stack;
import java.lang.StringBuilder;

public class Ratio {

	private GreatestCommonFactor gcfSet;
	private Stack<Integer> ratioSet;

	public Ratio() {
		this.gcfSet = new GreatestCommonFactor();
		this.ratioSet = new Stack<>();
	}

	public Ratio(Stack<Factors> factorStack) {
		this.gcfSet = new GreatestCommonFactor(factorStack);
		this.ratioSet = new Stack<>();
	}

	public Ratio(GreatestCommonFactor gcfSet) {
		this.gcfSet = gcfSet;
		this.ratioSet = new Stack<>();
	}

	public void addPart(int number) {
		this.ratioSet.push(number);
		this.gcfSet.addNumber(number);
	}

	public void deletePart(int position) {
		this.ratioSet.remove(position);
		this.gcfSet.deleteNumber(position);
	}

	private int commonDenominator() {
		return this.gcfSet.GCF();
	}

	private int dividePart(int number) {
		return number / this.commonDenominator();
	}

	public Stack<Integer> buildRatio() {

		Stack<Integer> ratio = new Stack<>();

		while (!(this.ratioSet.isEmpty())) {

			ratio.push(this.dividePart(this.ratioSet.pop()));
			
		}

		return ratio;
		
	}
	
	public String ratio() {

		StringBuilder ratioBuilder = new StringBuilder();
		String separator = ":";
		Stack<Integer> ratio = this.buildRatio();
		while (!(ratio.isEmpty())) {
			String part = ""; 
			if (ratio.size() > 1) {
				part = Integer.toString(ratio.pop());
				ratioBuilder.append(part + separator);
			} else {
				part = Integer.toString(ratio.pop());
				ratioBuilder.append(part);
			}
		}
		
		return ratioBuilder.toString();
		
	}

	public String toString() {

		return this.ratio();
		
	}
	
}