import java.util.Stack;

public class GreatestCommonFactor {

	private Stack<Factors> factorStack;

	/**
	 * 
	 * Creates a new Greatest Common Factor object
	 * 
	 */

	public GreatestCommonFactor() {
		this.factorStack = new Stack<>();
	}

	/**
	 * 
	 * Creates a new Greatest Common Factor object
	 * 
	 * @param factorStack the stack
	 * 
	 */

	public GreatestCommonFactor(Stack<Factors> factorStack) {
		this.factorStack = factorStack;
	}

	/**
	 * 
	 * Adds a stack to the factor stacks via a given number after creating a new
	 * Factors object
	 * 
	 * @param number the given number
	 * 
	 */

	public void addNumber(int number) {
		Factors factor = new Factors(number);
		this.factorStack.push(factor);
	}

	/**
	 * 
	 * Deletes a stack from the factor stacks via a given position
	 * 
	 * @param position the given position
	 * 
	 */

	public void deleteNumber(int position) {
		this.factorStack.remove(position);
	}

	/**
	 * 
	 * Determine whether the given number is a shared factor between each of the
	 * inner stacks of factors via deduction & negation, meaning that the number is
	 * automatically assumed to be a common factor of each of the stacks until there
	 * is evidence that it is not a common factor in each of the stacks. Hence, in
	 * order for the number to be considered a common factor, it must exist as a
	 * factor in each of the inner stacks. Even one stack without the number is
	 * enough to conclude that it is not a common factor.
	 * 
	 * @param number the given number
	 * @return whether it is a common factor or not
	 * 
	 */

	public boolean isCommonFactor(int number) {
		boolean criteriaMet = true;
		int i = 0, n = this.factorStack.size();
		while (i < n) {
			if (!(this.factorStack.get(i).isFactor(number))) {
				criteriaMet = false;
				break;
			}
			i++;
		}
		return criteriaMet;
	}

	/**
	 * 
	 * Build a stack of the common factors which exist from the set of numbers given
	 * by the user. (1) The algorithm creates a list of numbers from the user input
	 * by sifting through the original factor stack & retrieving the max numbers
	 * from the end of each stack. (2) The algorithm sifts through the list to find
	 * out the maximum number of the set provided by the user. (3) The algorithm
	 * uses that number to sift out the common factors & push the common factors
	 * into the stack. (4) The new stack is returned.
	 * 
	 * @return the stack of shared factors
	 * 
	 */

	private Stack<Integer> commonFactors() {
		Stack<Integer> commonFactors = new Stack<>();

		// Step 1: Creating a list of numbers the user input

		int[] numbers = new int[this.factorStack.size()];
		int maxNumber = 0, i = 0, n = numbers.length;
		while (i < n) {
			numbers[i] = this.factorStack.get(i++).getNumber();
		}

		i = 0;

		// Step 2: Finding out the maximum number

		while (i < n) {
			if (numbers[i] > maxNumber) {
				maxNumber = numbers[i];
			}
			i++;
		}

		// Step 3: Using that number to sift out the common factors & push common
		// factors into the stack

		i = 1;

		while (i < maxNumber) {
			if (this.isCommonFactor(i))
				commonFactors.push(i);
			i++;
		}

		// Step 4: Return the stack

		return commonFactors;

	}

	public int GCF() {

		int gcf = 0, i = 0, n = this.commonFactors().size();
		while (i < n) {
			if (this.commonFactors().get(i) > gcf) {
				gcf = this.commonFactors().get(i);
			}
			i++;
		}
		return gcf;

	}

	public String toString() {

		return this.commonFactors().toString() + "\nGCF: " + this.GCF();

	}

}