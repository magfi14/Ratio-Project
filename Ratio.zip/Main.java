class Main {
  public static void main(String[] args) {
		RatioScanner scanner = new RatioScanner();
		scanner.buildRatio();
  }
}