import java.util.Stack;

public class Factors {

	private Stack<Integer> factors;
	private int number;

	public Factors(int number) {
		this.number = number;
	}

	public boolean isFactor(int trialNumber) {
		return this.number % trialNumber == 0;
	}

	public int getNumber() {
		return this.number;
	}

	public Stack<Integer> factors() {
		int n = this.number, i = 1;
		factors = new Stack<>();
		while (i <= n) {
			if (isFactor(i)) {
				factors.push(i);
			}
			i++;
		}
		return factors;
	}

	public int[] arr() {
		int[] arr = new int[this.factors().size()];
		int elementsTakenOut = 0;
		while (!(factors.isEmpty())) {
			arr[elementsTakenOut] = factors.pop();
			elementsTakenOut++;
		}
		return arr;
	}

	public String toString() {
		String ret = "";
		ret += "Number: " + this.number;
		ret += "\nFactors: " + this.factors().toString();
		return ret;
	}

}